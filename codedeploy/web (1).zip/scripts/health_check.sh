#ValidateService
#Runs as myapp
#!/bin/bash
curl -f http://localhost:80 > /dev/null
chmod +x scripts/health_check.sh
