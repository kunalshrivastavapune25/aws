#AfterInstall
#!/bin/bash
yum install -y httpd curl
mkdir -p /var/www/html
chmod +x scripts/setup_environment.sh
