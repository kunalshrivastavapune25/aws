#ApplicationStart
#!/bin/bash
systemctl enable httpd
systemctl start httpd
chmod +x scripts/start_service.sh
