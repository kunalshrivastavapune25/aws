#BeforeInstall + ApplicationStop
#!/bin/bash
systemctl stop httpd || true
chmod +x scripts/stop_service.sh
