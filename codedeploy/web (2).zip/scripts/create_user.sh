#!/bin/bash
set -e  # exit on error

USERNAME="myapp"

# Check if user already exists
if id "$USERNAME" >/dev/null 2>&1; then
    echo "User $USERNAME already exists, skipping creation."
else
    sudo useradd -m -s /bin/bash "$USERNAME"
    echo "User $USERNAME created."
fi

# Optional: set password, add to groups, etc.
# echo "myapp:somepassword" | sudo chpasswd