#AfterInstall
#!/bin/bash
TOKEN=$(curl -s -X PUT "http://169.254.169.254/latest/api/token" \
-H "X-aws-ec2-metadata-token-ttl-seconds: 21600")

INSTANCE_ID=$(curl -s -H "X-aws-ec2-metadata-token: $TOKEN" \
http://169.254.169.254/latest/meta-data/instance-id)

PRIVATE_IP=$(curl -s -H "X-aws-ec2-metadata-token: $TOKEN" \
http://169.254.169.254/latest/meta-data/local-ipv4)

PUBLIC_IP=$(curl -s -H "X-aws-ec2-metadata-token: $TOKEN" \
http://169.254.169.254/latest/meta-data/public-ipv4)

AZ=$(curl -s -H "X-aws-ec2-metadata-token: $TOKEN" \
http://169.254.169.254/latest/meta-data/placement/availability-zone)

cat <<EOF > /var/www/html/index.html
<html>
<body>
<h1>Apache Web Server Running</h1>
<p>Instance ID: $INSTANCE_ID</p>
<p>Private IP: $PRIVATE_IP</p>
<p>Public IP: $PUBLIC_IP</p>
<p>Availability Zone: $AZ</p>
</body>
</html>
EOF

chmod 644 /var/www/html/index.html
chown root:root /var/www/html/index.html