#AfterInstall
#!/bin/bash
yum install -y httpd curl
mkdir -p /var/www/html

