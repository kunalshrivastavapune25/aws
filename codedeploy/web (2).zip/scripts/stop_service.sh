#BeforeInstall + ApplicationStop
#!/bin/bash
systemctl stop httpd || true
